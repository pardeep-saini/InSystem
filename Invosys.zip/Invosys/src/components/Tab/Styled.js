import styled from "styled-components"

export const Container =  styled.div`
        padding-left: 3%;
        padding-right: 3%;
        background-color: rgb(242, 242, 242);
`;

export const customStyles = {
        content: {
                paddingLeft: '3%',paddingRight: '3%',backgroundColor:'#f2f2f2'
        },
        serachBar: {
                backgroundColor: 'white', width: '96%',marginLeft: 'auto',marginRight: 'auto'
        },
        RouterContainer: {
                height: 400, width: '100%', backgroundColor: 'white'
        }
        
      };