import * as types from './spaceActionConstant';

export const getAllSpaceLaunchesAction = (val) => {
  return {
    type: types.GET_ALLSPACELAUNCHES,
    val  
  }
};

