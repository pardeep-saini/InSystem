import styled from "styled-components"

export const Container =  styled.div`
        padding-left: 3%;
        padding-right: 3%;
        background-color: rgb(242, 242, 242);
`;